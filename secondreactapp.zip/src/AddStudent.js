import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const AddStudent = () =>{
    const navigate = useNavigate();
    const [newstd, setNewstd] = useState({
        "id": 0,
        "sname": "",
        "course": "",
        "fees": 0.0
    });

    const NewStd = (e) =>{
        e.preventDefault();
        axios({
            url:"http://localhost:9090/Students",
            method:"POST",
            data:newstd,
        })
        .then((response)=>{
            console.log(response.data);
            //alert('New Student is Added..')
            navigate("/allstd");
        })
        .catch((err)=>{
            console.log(err);
        });
    };

    return(
        <div className="container-fluid">
            <div className="row">
                <div className="col-lg-3"></div>
                <div className="col-lg-6">
                    <div className="card">
                        <div className="card-header">
                            <b>Register here</b>
                        </div>
                        <div className="card-body">
                            <form onSubmit={NewStd}>
                            <label>Roll Number</label>
                            <input type="text"  name="rollno"  className="form-control" 
                            onChange={(e)=>{setNewstd({...newstd, id:e.target.value})}} />
                            <br />
                            <label>Student Name</label>
                            <input type="text"  name="sname"  className="form-control"
                            onChange={(e)=>{setNewstd({...newstd, sname:e.target.value})}} />
                            <br />
                            <label>Course</label>
                            <input type="text"  name="course"  className="form-control" 
                            onChange={(e)=>{setNewstd({...newstd, course:e.target.value})}} />
                            <br />
                            <label>Fees</label>
                            <input type="text"  name="fees"  className="form-control"
                            onChange={(e)=>{setNewstd({...newstd, fees:e.target.value})}} />
                            <div className="row">
                                <div className="col-lg-12" style={{'textAlign':'center'}}>
                                    <br />
                                        <input type="submit"  value="Add Student"  className="btn btn-primary" />
                                        &nbsp;&nbsp;&nbsp;&nbsp;
                                        <input type="reset"  value="Reset Form"  className="btn btn-danger" />
                                </div>
                            </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div className="col-lg-3"></div>
            </div>
        </div>
    );
}

export default AddStudent;