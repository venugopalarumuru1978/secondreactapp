import React, { useEffect, useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const ViewStudents = () =>{

    const [stdInfo, setStdInfo] = useState([]);
    const navigate = useNavigate();

    const AddStds = () =>{
        navigate("/newstd");
    }
    const AllStds = () =>{
        navigate("/allstd");
    }
    useEffect(()=>{
        ShowStdData();
    }, [stdInfo]);

    const ShowStdData = () =>{
        axios({
            url:"http://localhost:9090/Students",
            method:"GET",
            data:null,
        })
        .then((response)=>{
            setStdInfo(response.data);
            //console.log(stdInfo);
        })
        .catch((err)=>{
            console.log(err);
        });

        /*
        axios.get('http://localhost:9090/Students')
        .then((res)=>{
            setStdInfo(res.data);
            console.log(stdInfo);
        });
        */
    }

    return(
        <div  className="container-fluid">

            <br />
            <div className='row'>
        <div className='col-lg-12' style={{'textAlign':'center'}}>
          <input type="button"  value={"All Students"}  className='btn btn-primary' onClick={AllStds} />
          &nbsp;&nbsp;&nbsp;
          <input type="button"  value={"Add New Student"}  className='btn btn-primary' onClick={AddStds} />
        </div>
      </div>
<hr />
            <h1 style={{'textAlign':'center'}}>Students Data</h1>
            <hr />
            <div className="row">
                <div className="col-lg-12">
                    <table className="table table-success table-striped">
                        <thead>
                            <tr>
                                <th>Roll Number</th>
                                <th>Student Name</th>
                                <th>Course</th>
                                <th>Fees</th>
                            </tr>                            
                        </thead>
                        <tbody>
                            {
                                stdInfo.map((std)=>(
                                    <tr>
                                        <td>{std.id}</td>
                                        <td>{std.sname}</td>
                                        <td>{std.course}</td>
                                        <td>{std.fees}</td>
                                    </tr>
                                ))
                            }                            
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
}

export default ViewStudents;
