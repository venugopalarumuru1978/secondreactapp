import AddStudent from './AddStudent';
import './App.css';
import ViewStudents from './ViewStudents';
import { BrowserRouter, Route } from 'react-router-dom';
import { Routes } from 'react-router';

function App() {
  
  return (
    <div className="container-fluid">
     <BrowserRouter>
      <Routes>
        <Route path="/" exact Component={ViewStudents} />
        <Route path="/allstd" exact Component={ViewStudents} />
        <Route path="/newstd" exact Component={AddStudent} />
      </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
